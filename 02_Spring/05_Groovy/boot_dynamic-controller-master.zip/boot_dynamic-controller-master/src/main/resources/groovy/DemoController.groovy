package com.pantuo.web;
import java.security.Principal;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.Principal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import groovy.sql.Sql
import groovy.transform.CompileStatic;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Controller
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.context.annotation.Lazy;

import com.pantuo.*;
@RestController
public class ContractSQController {


	@Autowired
	@Lazy
	DemoInterface demoInterface;

	@RequestMapping(value = "/testGroovy")
	public def testGroovy(HttpServletRequest request) {

		return 	demoInterface.get("nihao")
	}
}
