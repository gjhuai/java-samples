package com.pantuo;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.pantuo.DemoInterface;
/**
 * 
 * <b><code>OrderValidatServiceImpl</code></b>
 * <p>
 * </p>
 * <b>Creation Time:</b> 2017年4月11日 下午3:55:10
 * @author impanxh@gmail.com
 * @since pantuo 1.0-SNAPSHOT
 */
@Service

public class DemoServiceImpl implements DemoInterface {
	public Map get(String c){

		def map =[:]
		map['key']='value'

		return map;
	}
}
