package com.pantuo;

import java.util.Map;

public interface DemoInterface {

	public Map get(String c);

}
