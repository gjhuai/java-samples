# 此示例用于 示范 spring boot 与 groovy的结合 使用
带来的好处 
可以在运行时期 动态增加controller 及各种service 相当于在线增加 动态功能

groovy说明 如果未熟悉或是未了解groovy
可以把groovy理解成.java扩展名改成.groovy就是 一最简单的groovy语言

groovy支持修改热部署


使用说明 
 @EnableGroovy
默认会从src/main/resources/groovy加载groovy脚本 

groovy目录下可以存放controller 及各种service 支持运行时动态加载

启动 

 


测试地址 http://127.0.0.1:8080/testGroovy
结果 
{
key: "value"
}

然后 修改 groovy再刷新url 测试结果
  
